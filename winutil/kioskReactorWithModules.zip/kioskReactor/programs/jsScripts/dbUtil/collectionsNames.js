module.exports = {
  devicesCollection: 'devices',
  projectsCollection: 'projects',
  brandsCollection: 'brands',
  deviceHealthCollection: 'deviceHealth',
  versionCollection: 'versions',
  eventsCollection: 'events',
  commandsCollection: 'commands',
}
