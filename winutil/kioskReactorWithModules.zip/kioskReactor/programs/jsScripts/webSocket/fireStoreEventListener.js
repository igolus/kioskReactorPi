import {initializeFirebase} from "../commandsListener/commandUtil";

initializeFirebase();



