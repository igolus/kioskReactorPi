const constants = {
    TRIGGER_WEB_HOOK_ACTION: "triggerWebHook",
    GO_TO_HOME_PAGE_ACTION: "gotoHomePage",
    GO_TO_PREVIOUS_PAGE_ACTION: "gotoPreviousPage",
    SEND_EVENT_ACTION: "sendEvent"
}

module.exports = {
    constants: constants
}